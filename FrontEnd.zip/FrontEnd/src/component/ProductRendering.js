import React from "react";
import Button from 'react-bootstrap/Button';
import { useNavigate } from 'react-router-dom';
import { Row, Col, Card } from 'react-bootstrap';

import { useDispatch, useSelector } from "react-redux";
import {
    selectedProduct,
  } from "../conatainer/redux/actions/productsAction";
  
const ProductRendering  = () => {
    const navigate = useNavigate();
    
  const dispatch = useDispatch();
  const products = useSelector((state) => state.allProducts.products);
  const renderList = products.map((product) => {
    const { _id, name, price,quantity } = product;

    const productDetails=()=>{
  
     dispatch(selectedProduct(product));
        navigate(`/product/${_id}`);

    }
    
    return (
<>
       <Col>
     
        <Card style={{ width: '18rem',backgroundColor: "whitesmoke",boxShadow:" 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)"}} >
        <Card.Img variant="top" src="" />
        <Card.Body>
          <Card.Title>{name}</Card.Title>
          <Card.Text>
            Some quick example text to build on the card title and make up the bulk of
            the card's content.
          </Card.Text>
          <Card.Text>${price}</Card.Text>
          <Card.Text>Toatl Quantity: {quantity}</Card.Text>
          <Button variant="primary" onClick={productDetails}>Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      {/* <div className="four wide column" key={id}>
        <Link to={`/product/${id}`}>
          <div className="ui link cards">
            <div className="card">
              <div className="image">
                <img src={image} alt={title} />
              </div>
              <div className="content">
                <div className="header">{title}</div>
                <div className="meta price">$ {price}</div>
                <div className="meta">{category}</div>
              </div>
            </div>
          </div>
        </Link>
      </div> */}
      </>
    );
  });
  return <Row className="d-flex mt-5">{renderList}</Row>;
};

export default ProductRendering;
