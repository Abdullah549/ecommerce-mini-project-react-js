   
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { Row, Col, Card } from 'react-bootstrap';


function CartComponent() {
    
    const cart = useSelector((state) => state.allProducts.cart);
    
  //  const [totalPrice,setTotalPrice]=useState(cart[0].price);
//const cart = useSelector((state) => state.cart);
  //const { name, price, _id, quantity } = product;
  //totalPrice+product.count*product.price
  const dispatch = useDispatch();
 const makeData = cart.data.map((product)=>{
 
 /// console.log("totalPrice is ",totalPrice)
    return(
       
        <>
          
    <tr>
      <td><Card.Title>{product.name}</Card.Title></td>
      <td>
      <Card.Text>{product.count}</Card.Text>
      </td>
      <td><Card.Text>${product.price}</Card.Text></td>
      <td><Card.Text>{product.count} x {product.price} = {product.count*product.price}</Card.Text></td>
      
    </tr>
                    
          {/* <Button variant="primary" onClick={()=>{navigate(`/product/${_id}`);}}>Add to cart</Button> */} 
    
    </>
    );
})



  return (
    <div className="">
      {/* width: '18rem', */}
      <Card style={{ backgroundColor: "whitesmoke",boxShadow:" 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)"}} >
      <Card.Img variant="top" src="" />
        <Card.Body>
        <table class="table">
  <thead class="table-dark">
  <tr>
      <th scope="col">Product Name</th>
      <th scope="col">Quantity</th>
      <th scope="col">Price</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
           
  {makeData}
   <tr>
       <td></td>
       <td></td>
       <td></td>
       <td>
            Total Price: ${ cart.totalPrice }
       </td>
   </tr>
  </tbody>
</table>

      </Card.Body>
    
      </Card>
    
    </div>
  );
}

export default CartComponent;
