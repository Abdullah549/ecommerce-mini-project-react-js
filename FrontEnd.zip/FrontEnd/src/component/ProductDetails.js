import React, { useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import Button from 'react-bootstrap/Button';
import { Row, Col, Card } from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux";
import {
  selectedProduct,
  //removeSelectedProduct,
  addToCart
} from "../conatainer/redux/actions/productsAction";

const ProductDetails = () => {
  const { productId } = useParams();
  
  const products = useSelector((state) => state.allProducts.products);
  
  const result = products.find( (product) => product._id === productId );
  const { name, price, _id, quantity } = result;
  
  const dispatch = useDispatch();
//   const fetchProductDetail = async (id) => {
    
//     const response = await axios
//       .get(`/courses/${productId}`)
//       .catch((err) => {
//         console.log("Err: ", err);
//       });
//     dispatch(selectedProduct(response.data));
//   };

  
//   useEffect(() => {

//     fetchProductDetail();
  

// }, []);
  const cartUpdate=()=>{

    dispatch(addToCart(result));
  }
   return (
    <div className="">
       <Row>
           <Col xl={6}></Col>
           <Col xl={6} >
               <Row  className="d-flex flex-column">
                   <Col className="mt-2"><h2>{name}</h2></Col>
                <Col className="mt-2">Dummy product description Dummy product description
                Dummy product descriptionDummy product descriptionDummy product description
                Dummy product descriptionDummy product descriptionDummy product descriptionDummy product description
                Dummy product descriptionDummy product descriptionDummy product description</Col>
                <Col className="mt-4">Price: ${price}</Col>
                <Col className="mt-4">Total Quantity: {quantity}</Col>
                <Col className="mt-4">
                {quantity>0?<Button variant="primary"  onClick={cartUpdate}>Add to cart</Button>:<div>Out of stock</div>}
          </Col>
               </Row>
               </Col>

           
           
       </Row>
      
      
    </div>
  );
};

export default ProductDetails;
