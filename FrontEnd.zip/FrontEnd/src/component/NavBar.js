import React from "react";
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom'

function NavBar(){
    const navigate = useNavigate()
    
    return(<>
    
        <nav class="navbar navbar-light bg-light justify-content-between">
        <Link to="/" >
    <a class="navbar-brand ms-3"  >Dummy</a>
    </Link>
    <form class="form-inline">
    <Link to="/cart" >
      <button class="btn btn-outline-success my-2 my-sm-0 me-3" >Cart</button>
      </Link>
    </form>
  </nav>
  </>);
};
export default NavBar;