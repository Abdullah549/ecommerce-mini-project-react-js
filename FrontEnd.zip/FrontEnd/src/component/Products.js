import ProductRendering from "./ProductRendering";
import { useEffect, useState } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setProducts } from "../conatainer/redux/actions/productsAction";


function Products() {
    ///////////////////////////////////////////////////
    const[flag,setFlag]=useState("0");
    const products = useSelector((state) => state.allProducts);
    
    const cart = useSelector((state) => state.allProducts.cart);
    const dispatch = useDispatch();
    const fetchProducts = async () => {

      const response = await axios
        .get("/courses")
        .catch((err) => {
          console.log("Err: ", err);
        });
        
        
        
      dispatch(setProducts(response.data));
    };
  
    useEffect(() => {
        
        if(cart.data.length<1){
            fetchProducts();
        }
      

    },[]);
  
    return (
      <div className="ui grid container">
         <ProductRendering /> 
      </div>
    );
};
  





    //////////////////////////////////////////////////////

//   useEffect(()=>{
//     console.log("useeffect called");
//     fetch('/courses', {
//       headers : { 
//         'Content-Type': 'application/json',
//         'Accept': 'application/json'
//        }

//     })
//   .then(response => response.json())
//   .then(data => console.log("2nd then",data))
//   .catch((err)=>{
//     console.log("err is",err);

//   })
//   })
//   return (

//         <div>welcome from products page</div>
//   );
// }

export default Products;
