import { ActionTypes } from "../constants/action-types";
const intialState = {
  products: [],
  product:[],
  cart:{
    data:[],
    totalPrice:0},
};

export const productsReducer = (state = intialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.SET_PRODUCTS:
      return {...state,  products: payload };
    case ActionTypes.SELECTED_PRODUCT:
      return {...state,product:payload };
    case ActionTypes.CartProducts:
      console.log("in  map",state.cart.length)
      const result = state.products.find( (product) => product._id === payload._id );
      if(result)
      {
        result.quantity=result.quantity-1
       
      }
   
      if(state.cart.data.length > 0){
      
        const result = state.cart.data.find( (product) => product._id === payload._id );
        if(result)
        {
          
         result.count=result.count+1
         return{...state,products:[...state.products],cart:{...state.cart,totalPrice:state.cart.totalPrice+result.price}}
        }
        else{
          
          payload.count=payload.count+1;
         
          return{...state,products:[...state.products],cart:{data:[...state.cart.data,payload],totalPrice:state.cart.totalPrice+payload.price}}
        }
      }
      else{

        payload.count=payload.count+1;
        return {...state,products:[...state.products],cart:{data:[payload],totalPrice:payload.price}};
      }
      
    default:
      return state;
  }
};

// export const selectedProductsReducer = (state = {products}, { type, payload }) => {
//   console.log(type);
//   switch (type) {
//     case ActionTypes.SELECTED_PRODUCT:
//       return {...state,product:payload };
//     // case ActionTypes.REMOVE_SELECTED_PRODUCT:
//     //   return {};
//      default:
//       return state;
//   }
// };

























// import { ActionTypes } from "../constants/action-types";
// const intialState = {
//   products: [],
//   selectedProduct:[],
//   };
// export const productsReducer = (state = intialState.products, { type, payload }) => {
//   switch (type) {
//     case ActionTypes.SET_PRODUCTS:
//       return { ...state, products: payload };
//     default:
//       return state;
//   }
// };

// export const selectedProductsReducer = (state = intialState.selectedProduct, { type, payload }) => {
//   console.log(type);
//   switch (type) {
//     case ActionTypes.SELECTED_PRODUCT:
//       return { product:payload };
//     case ActionTypes.REMOVE_SELECTED_PRODUCT:
//       return {};
//     case ActionTypes.AddToCart:
//       return {...state, ...payload};
//     default:
//       return state;
//   }
// };

// export const cartProductsReducer =(state = intialState ,{ type, payload })=>{
//   switch (type) {
//     case ActionTypes.AddToCart:
//       return {...state, cart:payload};
//     default:
//       return state;
//   }

// }
