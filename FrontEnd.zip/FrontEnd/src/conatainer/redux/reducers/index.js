import { combineReducers } from "redux";
import { productsReducer, selectedProductsReducer,cartProductsReducer } from "./productsReducer";
const reducers = combineReducers({
  allProducts: productsReducer,
  //product: selectedProductsReducer,
 // allProductsCart:cartProductsReducer,
});
export default reducers;
