import { useEffect } from "react";
import Product from "./component/Products"
import ProductDetails from "./component/ProductDetails";
import CartComponent from "./component/CartComponent";
import { Routes ,Route } from 'react-router-dom';
import { BrowserRouter as Router, Switch } from "react-router-dom";
import NavBar from "./component/NavBar";

function App() {

  
  return (
    <div className="App">
      
      <Router>
      <NavBar/>
        <Routes>
          <Route path="/" exact element={<Product/>} />
           <Route path="/product/:productId" element={<ProductDetails/>} />
           <Route path="/cart" element={<CartComponent/>} />
          <Route>404 Not Found!</Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
