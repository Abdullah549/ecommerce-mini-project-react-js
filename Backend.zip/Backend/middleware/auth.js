const jwt = require('jsonwebtoken');


const auth = (req,res,next) => {
    const token = req.header("x-auth-token");

    if(token){
     try{
           const decode = jwt.verify(token,"junoonvsnoon");
           req.user=decode;
           next()

        }
    catch(ex){
         res.status(400).send("invalid token ");

         }
        
    }
    else{
       return  res.status(401).send('access denaied no token provided');
    }

}
module.exports = auth;