const jwt = require('jsonwebtoken');


const admin = (req,res,next) => {
    
    if(req.user.admin){
     
           next()

        
    }
    else{
       return  res.status(401).send('access denaied no token provided');
    }

}
module.exports = admin;