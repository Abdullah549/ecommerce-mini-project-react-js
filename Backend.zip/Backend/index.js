const mongoose = require('mongoose');
var Joi = require('joi')
var express = require('express')
var app = express();
const courses = require('./routes/courses');
const authors = require('./routes/authors');
const user = require('./routes/user')

const auth = require('./routes/Auth')

mongoose.connect('mongodb://localhost/playground')
 .then(()=>{console.log("successfully connected to mongo db ..........")})
 .catch((err)=>{console.log("error: ",err)});




app.use(express.json());


//app.use('/authors',authors);
//app.use('/user',user);

//app.use('/auth',auth);
app.use('/courses',courses);
app.get('/',(req,res)=>{

    res.send('I will win not immediately but definately ')
});

app.listen(3000,()=>{
    console.log('server serve on port 3000....')
});

