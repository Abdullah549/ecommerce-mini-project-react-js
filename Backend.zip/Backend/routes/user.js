// const jwt = require('jsonwebtoken');
// const bcrypt = require('bcrypt');
// const _ = require("lodash")
// const express = require("express");
// const router = express.Router();
// const {User, UserValidation}= require("./UserSchema");
// const auth = require('../middleware/auth');


// router.get('/me',auth,async(req,res)=>{
//     const user = await User.findById(req.user._id);
//     res.send(user);

// })

// router.post('/login',async(req,res)=>{
//     console.log("in login router")
//     const {value,error}=UserValidation(req.body.name,req.body.email,req.body.password);
//     const user = await User.findOne({email:req.body.email});
//     if(user){
//         console.log("user register already ")
//         return res.status(404).send("user already register ");_

//     }
//     else {
//         if(!error){
//         const user = new User(_.pick(req.body,["name","email","password"]));
//         console.log(user);
//         const salt = await bcrypt.genSalt(10);
//         user.password = await bcrypt.hash(user.password,salt)
//         await user.save();
        
//         const token = user.generateAuthToken();

//         res.header("x-auth-toke",token).send(_.pick(user,["name","email"]));
//     }
//     else{
//         res.send(error.details[0].message);
//         console.log(error.details[0].message);
//     }

//     }



// });
// module.exports = router;