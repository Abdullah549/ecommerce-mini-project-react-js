// const jwt = require('jsonwebtoken');
// var Joi = require('joi');
// const mongoose = require('mongoose');
// const { boolean } = require('joi');

// const UserSchema = new mongoose.Schema({

//     name:{
//         type:String,
//         required:true,
//         minlength:5,  
//         max:255,      
//     },
//     email:{
//         type:String,
//         required:true,
//         unique:true
//     },
//     password:{
//         type:String,
//         required:true,
//         minlength:5,
//         max:1024,
//     },
//     admin:Boolean,
// });

// UserSchema.methods.generateAuthToken = function(){
//     const token = jwt.sign({_id:this._id,admin:this.admin},'junoonvsnoon');
//     return token;
// }

// const User = mongoose.model('User',UserSchema);

// const UserValidation = (name,email,password)=>{
//     const schema=Joi.object({
//         name:Joi.string().min(5).max(15).required(),
//         email:Joi.string().min(10).max(255).required().email(),
//         password:Joi.string().min(5).max(10).required(),

//     });
//     return {error,value}=schema.validate({name,email,password})
// }

// exports.User=User;
// exports.UserValidation=UserValidation;