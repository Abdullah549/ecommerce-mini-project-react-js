// const express=require('express');
// const router=express.Router();
// const {Author,authorValidation}= require('./AuthorSchema');


// router.get('/',async(req,res)=>{
//     console.log("in get all author router")
//     const author = await Author.find();
//     if(!author){
//         res.send("there is no registered author")
//     }
//     else{
//     res.send(author);
//     }
    
// });
// router.get('/:id',async(req,res)=>{
//     const author = await Author.findById(req.params.id)
//     if(!author){
//         res.statusCode(404).send('invalid id ')
        
//     }
//     else{
//         res.send(author);
//     }

// });
// router.post('/',async(req,res)=>{
//     const {value,error} = authorValidation(req.body.name,req.body.email);
//     console.log("value is ",value);
//     console.log("error is ",error);
//     if(error){
        
//         res.send("error coming from validation");
//         res.status(404).send(error.details[0].message);
//     }
//     else{
//         const author = new Author({
//             name:req.body.name,
//             accounts:{
                
//                 twitter:req.body.twitter,
//                 facebook:req.body.facebook,
//                 linkden:req.body.linkden,
//                 email:req.body.email,
//             },
//             totalCourses:req.body.totalCourses
//         });
//         console.log(author)
//         await author.save();
//         res.send(author); 
//     }
// });
// router.put('/:id',async(req,res)=>{
//     const {value,error}= authorValidation(req.body)
//     if(error){
//         res.statusCode(404).send(error.details[0].message);

//     }
//     else{
        
//         const author =await Author.findByIdAndUpdate(req.prams.id,{
//             name:req.body.name,
//             accounts:body.accounts.twitter,
//             facebook:body.accounts.facebook,
//             linkden:body.accounts.linkden,
//             email:body.accounts.email,
//             totalCourses:body.accounts,
//             new:true

//         });
//         if(!author){
//             res.status(404).send('course not found');
//         }
//         else{
//             res.send(author);
//         }

//     }
// });
// router.delete('/:id',async(req,res)=>{
//     const author= await Author.findByIdRemove(req.prams.id);
//     if(!author){
//         res.status(404).send("course not found");
//     }
//     else{
//         res.send(author);
//     }
// });
// module.exports= router;
