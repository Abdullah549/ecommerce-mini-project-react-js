const express = require('express');
// const auth = require('../middleware/auth')
// const {Author}= require('./AuthorSchema');
const router = express.Router();
// const admin = require('../middleware/admin');
const {Course,CourseValidation}= require('./CourseSchema');



router.get('/',async(req,res)=>{
    console.log('in get all route')
    const course =await Course.find();
    res.send(course)
});

router.get('/:id',async (req,res)=>{
    
    console.log('in get specific id')
    const course = await Course.findById(req.params.id);
    if(!course)
    {
        res.status(404).send('Course not found ID is invalid')
        console.log(course);
    }
    else{
        res.send(course);
        console.log(course);
    }
});
//auth,
router.post('/',async (req,res)=>{
    
    const {value,error}=CourseValidation(req.body.name,req.body.price,req.body.quantity);
    console.log("value : ",value );
    
    if(!error){
        const course = new Course({
            name:req.body.name,
            //  author:{
            //      _id:author._id,
            //      name:author.name,
            //  },
            price:req.body.price,
            quantity:req.body.quantity
        });
        await course.save();
        res.send(course);
    }
    if(error){
        res.status(400).send(error.details[0].message)
    }

});

router.put('/:id',async (req,res)=>{
    console.log('in put route ')
    const {value,error}=CourseValidation(req.body);
    if(value.name.length>0){
        console.log("value.name true")
        const course =await Course.findByIdAndUpdate(req.params.id,{name:req.body.name,
            new:true
        });
        
    if(!course)
    {
        res.status(404).send('Course not found ID is invalid')
        console.log(course);
    }
    res.send(course);
        
    
    }
    
    if(error){
        res.status(400).send(error.message)
    }

});
//,[auth,admin]
router.delete('/:id',async (req,res)=>{
    console.log('in delete route')
    const course =await Course.findByIdAndRemove(req.params.id);
    if(!course)
    {
        res.status(404).send('Course not found ID is invalid');
        console.log(course);
    }
    else{
        res.send(course);
        console.log(course);
    }

});


module.exports= router;