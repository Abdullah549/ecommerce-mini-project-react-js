var Joi = require('joi')
const mongoose = require('mongoose');

//const {AuthorSchema}= require('./AuthorSchema');
const CourseSchema = new mongoose.Schema({

    name:{
        type:String,
        required:true
    },
    price:{
        type: Number,
        required:true,
    },
    quantity:{
        type:Number,
        required:true
    },
    count:{
        type:Number,
        default:0
        
    },
    // author:{
    //     type:AuthorSchema,
    //     required:true

    // },
    // tags:[String],
    date:{type:Date, default:Date.now}
    //isPublished:Boolean

});

const Course = mongoose.model('Course',CourseSchema);


const CourseValidation = (name,price,quantity)=>{
    console.log("in course validation name is ", name);
    console.log("in course validation price is ",price);
    
    console.log("in course validation quantity is ",quantity);
    const schema = Joi.object({
        name: Joi.string().min(3).required(),
        price:Joi.string().required().min(1),
        quantity:Joi.string().required().min(1),        
    });
    return { error, value } = schema.validate({name,price,quantity});
    
    
}

exports.Course=Course;
exports.CourseValidation=CourseValidation;
