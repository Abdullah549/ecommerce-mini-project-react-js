// const bcrypt = require('bcrypt');
// const _ = require("lodash");
// const jwt = require('jsonwebtoken');
// const express = require("express");
// const router = express.Router();
// var Joi = require('joi');

// const {User}= require("./UserSchema");
// const Validation = (email,password)=>{
//     const schema=Joi.object({
//         email:Joi.string().min(10).max(255).required().email(),
//         password:Joi.string().min(5).max(10).required(),

//     });
//     return {error,value}=schema.validate({email,password})
// }



// router.post('/',async(req,res)=>{
//     console.log("in auth router")
//     const {value,error}=Validation(req.body.email,req.body.password);
//     const user = await User.findOne({email:req.body.email});
//     if(!error){
//          if(user){
//               const compareResult=await bcrypt.compare(req.body.password,user.password);
//               console.log("pass compare result is ",compareResult);
//               if(compareResult){
//                   const token = user.generateAuthToken();
//                    return res.status(200).send(token);_

//                 }
//              else{
//                   return res.status(404).send("incorrect password ");_
//                 }
        
//             }
//          else{
//               return res.status(404).send("invalid email and password")
//             }

//     }
//     else{
//         res.send(error.details[0].message);
//         console.log(error.details[0].message);
//     }

   


// });
// module.exports = router;