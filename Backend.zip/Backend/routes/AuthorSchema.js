// var Joi = require('joi');
// const mongoose = require('mongoose');

// const AuthorSchema = new mongoose.Schema({
//     name:{
//         type:String,
//         required:true
//     },
//     accounts:{
//         twitter:{
//             type:String
//         },
//         facebook:{
//             type:String
//         },
//         linkden:{
//             type:String
//         },
//         email:{
//             type:String,
//         }
//     },
//     totalCourses:{
//         type:String,
//     },
        
// });

// const Author = mongoose.model('Author',AuthorSchema);

// const authorValidation = (name,email)=>{
//     console.log("author validation name is =",name);
//     console.log("author validation accounts is =",email);
//     const schema = Joi.object({
//         name:Joi.string().min(3).required(),
//         email: Joi.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net'] } })

//     });
//     return {error,value}=schema.validate({name,email});
// }
// exports.Author=Author;
// exports.authorValidation=authorValidation;
// exports.AuthorSchema=AuthorSchema;